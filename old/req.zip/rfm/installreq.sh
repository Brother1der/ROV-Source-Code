#!/bin/bash

echo "Installing Python 3.11.14"
tar -xf Python-3.11.14.tar.xz

echo "Installing Python dependencies"
pip install -r requirements.txt