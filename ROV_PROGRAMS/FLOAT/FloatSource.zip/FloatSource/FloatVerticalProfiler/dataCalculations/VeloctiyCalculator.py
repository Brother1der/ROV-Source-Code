### Last Modified 12/9/2025
# Built by Conner O'Reilly
# Purpose: This program is designed to calculate the velocity using the pressure sensor data. Data is smoothed based on the
# duration provided by the user.
# Requirements: Device with full python support Pressure sensor float build.
###
from FloatSource.FloatVerticalProfiler.pressureSensor.PressureSensorData import PressureSensorData

class VelocityCalculator:
    def __init__(self, sensor_data: PressureSensorData ):
        """
        Initialize the velocityCalculator with a pressureSensorData instance.

        Args:
            sensor_data (pressureSensorData): The sensor data object that provides
                                             access to depth measurements.
        """
        self.sensorData = sensor_data


    def update_velocity(self) -> float:
        """
        Low-lag exponentially smoothed velocity.
        No long window averaging (removes phase lag).
        """

        samples = list(self.sensorData.get_recent_depth())
        if len(samples) < 2:
            return 0.0

        time_prev, depth_prev = samples[-2]
        time_curr, depth_curr = samples[-1]

        dt = time_curr - time_prev
        if dt <= 1e-6:
            return 0.0

        raw_velocity = (depth_curr - depth_prev) / dt

        # Exponential smoothing (tune 0.15–0.35)
        alpha = 0.35

        if not hasattr(self, "_filtered_velocity"):
            self._filtered_velocity = raw_velocity

        self._filtered_velocity = (
            alpha * raw_velocity +
            (1 - alpha) * self._filtered_velocity
        )

        return self._filtered_velocity


