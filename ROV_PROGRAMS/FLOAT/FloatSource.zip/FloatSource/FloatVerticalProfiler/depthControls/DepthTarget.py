from FloatSource.FloatVerticalProfiler.pressureSensor.PressureSensorData import PressureSensorData
from FloatSource.FloatVerticalProfiler.dataCalculations.VeloctiyCalculator import VelocityCalculator
from FloatSource.FloatVerticalProfiler.dataCalculations.AccelerationCalculator import AccelerationCalculator
from FloatSource.FloatVerticalProfiler.motorControls.MotorController import MotorController
import time
import math

class DepthTarget:

    UP = "CCW"
    DOWN = "CW"

    PWM_PIN = 18
    INA_PIN = 16
    INB_PIN = 17
    PWM_FREQ = 1000

    INTERVAL = 0.3  # control loop period (s)

    def __init__(self, sensor_data: PressureSensorData, up: str, down: str):
        self.UP = up
        self.DOWN = down
        self.cur_direction = None

        self.sensorData = sensor_data
        self.velocity_calculator = VelocityCalculator(sensor_data)
        self.acceleration_calculator = AccelerationCalculator(sensor_data)
        self.motorController = MotorController(
            self.PWM_PIN, self.INA_PIN, self.INB_PIN, self.PWM_FREQ
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _drive(self, direction: str, duty: int):
        if direction != self.cur_direction:
            self.motorController.update_direction(direction)
            self.cur_direction = direction
        self.motorController.set_speed(duty)

    def _wait(self, loop_start: float):
        remaining = self.INTERVAL - (time.time() - loop_start)
        if remaining > 0:
            time.sleep(remaining)

    def _read(self):
        # Median of last 9 depth samples to suppress ±2cm sensor noise.
        # 9 samples at 50ms polling = 450ms window; median noise ≈ σ/3 ≈ 0.007m.
        recent = self.sensorData.get_recent_depth()
        if len(recent) >= 9:
            last9 = sorted(s[1] for s in recent[-9:])
            depth = last9[4]  # middle value = median of 9
        elif len(recent) >= 5:
            last5 = sorted(s[1] for s in recent[-5:])
            depth = last5[2]  # middle value = median of 5
        else:
            depth = self.sensorData.get_latest_depth()[1]

        # VelocityCalculator uses EMA on consecutive samples — call with no args.
        vel = self.velocity_calculator.update_velocity()
        acc = self.acceleration_calculator.update_acceleration(0.3)
        return depth, vel, acc

    # ------------------------------------------------------------------
    # Go to target depth
    # ------------------------------------------------------------------

    def go_to_target(self, target_depth):
        """
        Drive to target_depth using a tanh velocity-profile controller.

        Physics: 120 RPM / 4mm pitch = 8 mm/s linear = ~10 mL/s max volume rate.
        Syringe usable: ±100 mL. Net buoyancy at max offset ≈ ±1 N on 12 kg float.

        Key fix: MIN_DUTY=0 allows proportional control to actually work.
        With MIN_DUTY > 0, the motor never stops at target velocity and
        continuously overbuilds syringe offset → runaway overspeed.

        BRAKE_GAIN=2.0 starts deceleration ~0.5 m before target, giving the
        slow-acting syringe enough time to reverse buoyancy before arrival.
        """
        POSITION_TOL = 0.08  # 8 cm capture zone (4× the 2 cm sensor noise)
        MAX_VEL = 0.06       # m/s — 4× higher than before; 2.1m transit ≈ 35-40s
        BRAKE_GAIN = 0.68     # gradual decel over ~0.5 m window (syringe needs time)
        MIN_VEL = 0.008      # min target velocity to prevent stalling near target
        MIN_DUTY = 0         # CRITICAL: allow motor to stop at target velocity
        MAX_DUTY = 80        # maximum PWM duty cycle
        KP_VEL = 400         # duty per m/s of velocity error
        VEL_HYST = 0.01      # hysteresis before declaring overspeed

        VEL_EXIT = 0.012     # exit once velocity settles below this
        ZONE_TIMEOUT = 8.0   # fallback exit after this many seconds in the zone
        LOOP_DT = 0.35       # 10 Hz control loop

        zone_entry = None

        while True:
            start = time.time()
            depth, vel, _ = self._read()
            error = target_depth - depth

            # Exit: within position tolerance AND velocity settled (or timed out)
            if abs(error) <= POSITION_TOL:
                if zone_entry is None:
                    zone_entry = time.time()
                if abs(vel) <= VEL_EXIT or (time.time() - zone_entry) >= ZONE_TIMEOUT:
                    self.motorController.set_speed(0)
                    print(f"TARGET REACHED: depth={depth:.3f}m vel={vel:+.3f} target={target_depth}m")
                    break
            else:
                zone_entry = None

            want_down = error > 0
            dir_sign = 1 if want_down else -1

            # Target velocity: tanh profile — full speed far out, ramps to zero near target
            target_vel = dir_sign * max(MIN_VEL, MAX_VEL * math.tanh(BRAKE_GAIN * abs(error)))

            vel_err = target_vel - vel

            # Overspeed: float moving faster than desired in the travel direction
            if want_down:
                overspeeding = vel > target_vel + VEL_HYST
            else:
                overspeeding = vel < target_vel - VEL_HYST

            if not overspeeding:
                direction = self.DOWN if want_down else self.UP
            else:
                direction = self.UP if want_down else self.DOWN

            # Proportional duty — MIN_DUTY=0 so motor stops when vel_err≈0
            duty = int(min(MAX_DUTY, max(MIN_DUTY, KP_VEL * abs(vel_err))))
            self._drive(direction, duty)

            print(f"  go_to: depth={depth:.3f} err={error:+.3f} "
                  f"tvel={target_vel:+.3f} vel={vel:+.3f} "
                  f"duty={duty} {'BRAKE' if overspeeding else 'DRIVE'}")

            elapsed = time.time() - start
            time.sleep(max(0, LOOP_DT - elapsed))

    # ------------------------------------------------------------------
    # Hold at target depth
    # ------------------------------------------------------------------

    def depth_hold(self, target_depth: float, duration: float = 35.0, tolerance: float = 0.33):
        """
        Hold at target_depth for `duration` seconds (wall-clock, always counting).

        PD control with coast-when-approaching logic:

          Coast rule: if error × vel > 0, the float is naturally moving toward
          target — motor off, let physics work.

          PD rule:  correction = Kd × (−vel) + Kp × error
            Kd (velocity term) damps residual motion immediately on arrival.
            Kp (position term) restores trim after slow drift.
          Positive correction → DOWN (CW, fill syringe, less buoyant)
          Negative correction → UP  (CCW, drain syringe, more buoyant)

          If |error| > tolerance: call go_to_target to re-acquire.
        """
        Kd        = 800    # duty per m/s — primary velocity damping
        Kp        = 50     # duty per m   — position restore
        DEADBAND  = 5      # min |correction| to act; keeps motor quiet near noise floor
        MAX_DUTY  = 60
        MIN_DUTY  = 10

        hold_timer = 0.0

        while hold_timer < duration:
            t = time.time()
            depth, vel, _ = self._read()
            hold_timer += self.INTERVAL

            error = target_depth - depth

            if abs(error) > tolerance:
                print(f"  hold: DRIFT {error:+.3f}m outside ±{tolerance}m, re-acquiring")
                self.go_to_target(target_depth)
                continue

            if error * vel > 0:
                # Float is heading toward target naturally — coast
                self.motorController.set_speed(0)
                print(f"  hold: depth={depth:.3f} vel={vel:+.3f} COAST  ({hold_timer:.0f}/{duration:.0f}s)")
            else:
                # Apply PD: damp velocity + restore position
                correction = Kd * (-vel) + Kp * error
                if abs(correction) < DEADBAND:
                    self.motorController.set_speed(0)
                    print(f"  hold: depth={depth:.3f} vel={vel:+.3f} OK  ({hold_timer:.0f}/{duration:.0f}s)")
                else:
                    direction = self.DOWN if correction > 0 else self.UP
                    duty = int(min(MAX_DUTY, max(MIN_DUTY, abs(correction))))
                    self._drive(direction, duty)
                    print(f"  hold: depth={depth:.3f} vel={vel:+.3f} err={error:+.3f} "
                          f"PD={correction:+.1f} {direction} {duty}%  ({hold_timer:.0f}/{duration:.0f}s)")

            self._wait(t)
